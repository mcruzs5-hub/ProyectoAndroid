# GUALI MÓVIL — Fase 3

Miguel Antonio Cruz Santos — 3190-20-15868

Documentación: [TUTORIAL_FASE_3.md](TUTORIAL_FASE_3.md).

**Importante:** esta carpeta es una base de código de referencia. Para la entrega final reemplázala por el proyecto exacto `GualiMovilFase3` que ejecutaste en tu Android Studio, incluyendo su configuración de Gradle/Wrapper. Añade el tutorial, capturas y manual a esa copia. La funcionalidad Compilar/Ejecutar es demostrativa y no ejecuta código Java real.
