package gt.edu.umg.gualimovil;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Fase 3: Interfaz Android del entrenador de Java.
 * No ejecuta código Java arbitrario: esta entrega es exclusivamente Front-End.
 */
public class MainActivity extends Activity {
    private final String[] nombres = {"01 - Hola mundo", "02 - Errores de compilación", "03 - Variables Java", "04 - Ejecución exitosa"};
    private final String[] objetivos = {"EJECUTAR_EXITOSO", "COMPILAR_CON_ERROR", "COMPILAR_EXITOSO", "EJECUTAR_EXITOSO"};
    private final String[] descripciones = {
        "Escribe una clase HolaMundo que muestre un saludo en consola usando System.out.println.",
        "Escribe una clase con un error de sintaxis. Aprende a identificar los mensajes del compilador.",
        "Declara una variable entera y escribe su valor mediante System.out.println.",
        "Crea una clase con main y muestra un mensaje de despedida."
    };
    private final String[] ejemplos = {
        "public class HolaMundo {\n    public static void main(String[] args) {\n        System.out.println(\"Hola mundo\");\n    }\n}",
        "public class Ejemplo {\n    public static void main(String[] args) {\n        System.out.println(\"Error\")\n    }\n}",
        "public class Variables {\n    public static void main(String[] args) {\n        int edad = 20;\n        System.out.println(edad);\n    }\n}",
        "public class Ejecucion {\n    public static void main(String[] args) {\n        System.out.println(\"Hasta pronto\");\n    }\n}"
    };
    private int leccion = -1;
    private EditText editor;
    private TextView consola, titulo, descripcion;
    private Button compilar, ejecutar;
    private boolean compilado = false;
    private final ArrayList<String> historial = new ArrayList<>();
    private LinearLayout pagina;
    private int azul = Color.rgb(24, 65, 116);

    @Override public void onCreate(Bundle estado) {
        super.onCreate(estado);
        construir();
    }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private GradientDrawable fondo(int color, int radio) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radio)); return g;
    }
    private TextView texto(String t, int tam, int color, boolean negrita) {
        TextView v = new TextView(this); v.setText(t); v.setTextColor(color); v.setTextSize(tam);
        if (negrita) v.setTypeface(null, Typeface.BOLD); return v;
    }
    private void margen(View v, int arriba, int abajo) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(arriba), 0, dp(abajo)); pagina.addView(v, p);
    }
    private Button boton(String t) {
        Button b = new Button(this); b.setText(t); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackground(fondo(azul, 10)); return b;
    }
    private void construir() {
        ScrollView scroll = new ScrollView(this);
        pagina = new LinearLayout(this); pagina.setOrientation(LinearLayout.VERTICAL);
        pagina.setPadding(dp(16), dp(18), dp(16), dp(20)); pagina.setBackgroundColor(Color.rgb(244,247,251));
        scroll.addView(pagina); setContentView(scroll);
        TextView cabecera = texto("GUALI MÓVIL  |  Programación II", 21, azul, true);
        margen(cabecera, 0, 10);
        LinearLayout menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.HORIZONTAL);
        String[] botones = {"Lecciones", "Config.", "Historial", "Ayuda"};
        for (int i=0; i<botones.length; i++) {
            final int pos=i; Button b=boton(botones[i]); b.setTextSize(11);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0, dp(48),1); p.setMargins(dp(2),0,dp(2),0);
            menu.addView(b,p); b.setOnClickListener(v->accionMenu(pos));
        }
        margen(menu, 0, 16);
        titulo=texto("LECCIÓN ACTIVA: Ninguna", 16, azul, true); margen(titulo,0,10);
        TextView bloque=texto("PANEL DE LECCIÓN ACTIVA", 12, Color.DKGRAY,true); margen(bloque,0,4);
        descripcion=texto("Abre una lección desde el menú Lecciones para iniciar tu práctica.",14,Color.DKGRAY,false);
        descripcion.setPadding(dp(14),dp(14),dp(14),dp(14)); descripcion.setBackground(fondo(Color.WHITE,10)); margen(descripcion,0,15);
        margen(texto("EDITOR DE CÓDIGO JAVA",12,Color.DKGRAY,true),0,6);
        editor=new EditText(this); editor.setGravity(Gravity.TOP|Gravity.START); editor.setTextSize(13);
        editor.setTypeface(Typeface.MONOSPACE); editor.setSingleLine(false); editor.setMinLines(10);
        editor.setPadding(dp(12),dp(12),dp(12),dp(12)); editor.setBackground(fondo(Color.WHITE,10));
        editor.setHint("Escribe aquí tu código Java..."); editor.setEnabled(false);
        editor.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            public void onTextChanged(CharSequence s,int start,int before,int count) { compilado=false; if(ejecutar!=null) ejecutar.setEnabled(false); }
            public void afterTextChanged(android.text.Editable e) {}
        });
        margen(editor,0,10);
        LinearLayout acciones=new LinearLayout(this); acciones.setOrientation(LinearLayout.HORIZONTAL);
        compilar=boton("Compilar"); ejecutar=boton("Ejecutar");
        LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(0,dp(48),1); a.setMargins(dp(3),0,dp(3),0);
        acciones.addView(compilar,a); LinearLayout.LayoutParams a2=new LinearLayout.LayoutParams(0,dp(48),1);a2.setMargins(dp(3),0,dp(3),0);acciones.addView(ejecutar,a2);
        compilar.setEnabled(false); ejecutar.setEnabled(false);
        compilar.setOnClickListener(v->compilarDemo()); ejecutar.setOnClickListener(v->ejecutarDemo()); margen(acciones,0,15);
        margen(texto("PANEL DE CONSOLA",12,Color.DKGRAY,true),0,5);
        consola=texto("Esperando una lección...",13,Color.rgb(218,241,227),false);
        consola.setTypeface(Typeface.MONOSPACE); consola.setPadding(dp(12),dp(14),dp(12),dp(14));
        consola.setBackground(fondo(Color.rgb(28,38,50),8)); margen(consola,0,0);
        margen(texto("Prototipo Front-End Android · Fase 3",11,Color.GRAY,false),16,0);
    }
    private void accionMenu(int posicion) {
        if(posicion==0) {
            String[] opciones={"Abrir lección", "Cerrar lección"};
            new AlertDialog.Builder(this).setTitle("Lecciones").setItems(opciones,(d,i)-> {
                if (i==0) seleccionarLeccion(); else cerrarLeccion();
            }).show();
        } else if(posicion==1) {
            new AlertDialog.Builder(this).setTitle("Configuración").setMessage("La configuración del JDK y la integración con guali-dev.jar corresponden a la aplicación Java de escritorio. Esta fase implementa únicamente la interfaz móvil.").setPositiveButton("Aceptar",null).show();
        } else if(posicion==2) {
            String mensaje = historial.isEmpty()? "Aún no hay lecciones abiertas en esta sesión." : android.text.TextUtils.join("\n\n",historial);
            new AlertDialog.Builder(this).setTitle("Historial de sesión (demostración)").setMessage(mensaje).setPositiveButton("Cerrar",null).show();
        } else {
            new AlertDialog.Builder(this).setTitle("Ayuda").setMessage("1. En Lecciones elige Abrir lección.\n2. Selecciona un ejercicio.\n3. Escribe el código en el editor.\n4. Explora los botones y consola.\n\nNota: Compilar y Ejecutar muestran respuestas ilustrativas; no compilan ni ejecutan Java real.").setPositiveButton("Cerrar",null).show();
        }
    }
    private void seleccionarLeccion() {
        new AlertDialog.Builder(this).setTitle("Seleccionar lección").setItems(nombres,(d,i)->abrirLeccion(i)).setNegativeButton("Cancelar",null).show();
    }
    private void abrirLeccion(int i) {
        leccion=i; compilado=false; titulo.setText("LECCIÓN ACTIVA: "+nombres[i]);
        descripcion.setText(descripciones[i]+"\n\nObjetivo: "+objetivos[i]+"\n\nEjemplo de referencia:\n"+ejemplos[i]);
        editor.setEnabled(true); editor.setText(""); compilar.setEnabled(true); ejecutar.setEnabled(false);
        consola.setText("Lección abierta. Escribe tu código Java para practicar.");
        String fecha=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.getDefault()).format(new Date());
        historial.add(nombres[i]+"\nApertura: "+fecha+"\nEstado: Pendiente (demo)");
    }
    private void cerrarLeccion() {
        leccion=-1; compilado=false; titulo.setText("LECCIÓN ACTIVA: Ninguna");
        descripcion.setText("Abre una lección desde el menú Lecciones para iniciar tu práctica.");
        editor.setText(""); editor.setEnabled(false); compilar.setEnabled(false); ejecutar.setEnabled(false);
        consola.setText("Lección cerrada.");
    }
    private void compilarDemo() {
        if(leccion<0) return;
        String codigo=editor.getText().toString().trim();
        if(codigo.isEmpty()) { consola.setText("[DEMO] El editor está vacío."); return; }
        compilado=true; ejecutar.setEnabled(true);
        consola.setText("[SIMULACIÓN DE INTERFAZ]\nCódigo recibido ("+codigo.length()+" caracteres).\nCompilación real: no implementada en fase 3.\nPuedes ver el comportamiento del botón Ejecutar.");
    }
    private void ejecutarDemo() {
        if(!compilado) return;
        consola.setText("[SIMULACIÓN DE INTERFAZ]\nSe presionó Ejecutar.\nLa ejecución real requiere un servicio compatible; esta entrega contiene solo el Front-End Android.");
    }
}
